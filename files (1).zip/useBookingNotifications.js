/**
 * useBookingNotifications.js — realtime push, separata badge-räknare
 */
import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '../services/supabaseClient';

const STORAGE_DEVICE       = 'islamnu_device_id';
const STORAGE_ADMIN        = 'islamnu_admin_mode';
const STORAGE_VISITOR_SEEN = 'islamnu_bookings_visitor_seen';
const STORAGE_ADMIN_SEEN   = 'islamnu_bookings_admin_seen';
const STORAGE_HAS_BOOKING  = 'islamnu_has_booking';
const POLL_INTERVAL_MS     = 30_000;

export function useBookingNotifications() {
  const [visitorUnread,     setVisitorUnread]     = useState(0);
  const [adminUnread,       setAdminUnread]       = useState(0);  // inloggad admin
  const [adminPendingCount, setAdminPendingCount] = useState(0);  // admin-device ej inloggad
  const [bellNotifs,        setBellNotifs]        = useState([]);
  const [active,            setActive]            = useState(false);

  const deviceId    = localStorage.getItem(STORAGE_DEVICE);
  const isAdminRef  = useRef(localStorage.getItem(STORAGE_ADMIN) === 'true');
  isAdminRef.current = localStorage.getItem(STORAGE_ADMIN) === 'true';

  const calculate = useCallback(async () => {
    const isAdmin = isAdminRef.current;

    // 1. Besökar-notiser
    if (deviceId) {
      const seenAt = parseInt(localStorage.getItem(STORAGE_VISITOR_SEEN) || '0', 10);
      const { data } = await supabase
        .from('bookings')
        .select('id, status, resolved_at, date, time_slot, admin_comment')
        .eq('device_id', deviceId)
        .in('status', ['approved', 'rejected', 'cancelled', 'edited'])
        .gt('resolved_at', seenAt);
      if (data) {
        setVisitorUnread(data.length);
        setBellNotifs(data.map(b => ({
          id: b.id, type: 'booking', status: b.status,
          date: b.date, time_slot: b.time_slot, admin_comment: b.admin_comment,
        })));
      }
    }

    // 2. Admin inloggad — pending räknare
    if (isAdmin) {
      const adminSeenAt = parseInt(localStorage.getItem(STORAGE_ADMIN_SEEN) || '0', 10);
      const { data } = await supabase
        .from('bookings')
        .select('id, created_at')
        .in('status', ['pending', 'edit_pending'])
        .gt('created_at', adminSeenAt);
      if (data) setAdminUnread(data.length);
      setAdminPendingCount(0);
    }

    // 3. Admin-device ej inloggad
    if (deviceId && !isAdmin) {
      const { data: adminDevice } = await supabase
        .from('admin_devices')
        .select('device_id, dismissed_at')
        .eq('device_id', deviceId)
        .maybeSingle();

      if (adminDevice && !adminDevice.dismissed_at) {
        const { count } = await supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .in('status', ['pending', 'edit_pending']);
        setAdminPendingCount(count ?? 0);
      } else {
        setAdminPendingCount(0);
      }
    }
  }, [deviceId]); // eslint-disable-line

  // Aktivering
  useEffect(() => {
    const isAdmin = isAdminRef.current;
    if (isAdmin) { setActive(true); return; }
    if (!deviceId) return;

    supabase
      .from('admin_devices')
      .select('device_id, dismissed_at')
      .eq('device_id', deviceId)
      .maybeSingle()
      .then(({ data }) => {
        if (data && !data.dismissed_at) { setActive(true); return; }
        const cached = localStorage.getItem(STORAGE_HAS_BOOKING);
        if (cached === 'true') { setActive(true); return; }
        if (cached === 'false') return;
        supabase
          .from('bookings')
          .select('id', { count: 'exact', head: true })
          .eq('device_id', deviceId)
          .then(({ count }) => {
            const has = (count ?? 0) > 0;
            localStorage.setItem(STORAGE_HAS_BOOKING, has ? 'true' : 'false');
            if (has) setActive(true);
          })
          .catch(() => {});
      })
      .catch(() => {});
  }, [deviceId]); // eslint-disable-line

  // Realtime + polling
  useEffect(() => {
    if (!active) return;
    calculate();
    const channel = supabase
      .channel('booking-notif-rt-v2')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' }, calculate)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'admin_devices' }, calculate)
      .subscribe();
    const poll = setInterval(calculate, POLL_INTERVAL_MS);
    return () => { supabase.removeChannel(channel); clearInterval(poll); };
  }, [active, calculate]);

  const activateForDevice = useCallback(() => {
    localStorage.setItem(STORAGE_HAS_BOOKING, 'true');
    setActive(true);
  }, []);

  const registerAdminDevice = useCallback(async () => {
    if (!deviceId) return;
    await supabase
      .from('admin_devices')
      .upsert({ device_id: deviceId, created_at: Date.now(), dismissed_at: null },
               { onConflict: 'device_id' });
    isAdminRef.current = true;
    setActive(true);
    setTimeout(calculate, 100);
  }, [deviceId, calculate]);

  const dismissAdminDevice = useCallback(async () => {
    if (!deviceId) return;
    await supabase
      .from('admin_devices')
      .update({ dismissed_at: Date.now() })
      .eq('device_id', deviceId);
    setAdminPendingCount(0);
  }, [deviceId]);

  const markVisitorSeen = useCallback(() => {
    localStorage.setItem(STORAGE_VISITOR_SEEN, Date.now().toString());
    setVisitorUnread(0);
    setBellNotifs([]);
  }, []);

  const markAdminSeen = useCallback(() => {
    localStorage.setItem(STORAGE_ADMIN_SEEN, Date.now().toString());
    setAdminUnread(0);
  }, []);

  const isAdmin = isAdminRef.current;
  const totalUnread =
    (deviceId ? visitorUnread : 0) +
    (isAdmin ? adminUnread : adminPendingCount);

  return {
    visitorUnread,
    adminUnread,
    adminPendingCount,
    totalUnread,
    bellNotifs,
    activateForDevice,
    registerAdminDevice,
    dismissAdminDevice,
    markVisitorSeen,
    markAdminSeen,
  };
}

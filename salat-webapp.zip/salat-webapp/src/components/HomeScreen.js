import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { useTheme } from '../context/ThemeContext';
import { useCountdown } from '../hooks/useCountdown';
import { fetchPrayerTimes, fetchTomorrowPrayerTimes, calcMidnight } from '../services/prayerApi';
import {
  PRAYER_NAMES, PRAYER_SWEDISH, fmt24, fmtCountdown,
  getTodayDateStr, timeToSec, swedishDate, formatHijri,
} from '../utils/prayerUtils';
import LocationModal from './LocationModal';
import { reverseGeocode } from '../services/prayerApi';

function enrichWithMidnight(timings, nextFajr) {
  if (!timings) return timings;
  if (timings.Midnight && timings.Midnight !== '--:--') return timings;
  return { ...timings, Midnight: calcMidnight(timings.Isha, nextFajr || timings.Fajr) };
}

/**
 * Determines which prayer is currently "active" (i.e. its time has begun but
 * the next prayer hasn't started yet), and which are passed.
 *
 * Special rules:
 * - Shuruq (Sunrise) is never "active" — it's an information-only time.
 * - Midnight is active from its time until Fajr (across midnight).
 * - All others: active from their own time until the next prayer's time.
 */
function getPrayerStatus(times, nowSec) {
  if (!times) return {};

  const order = ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha', 'Midnight'];
  const secs = {};
  order.forEach(n => { secs[n] = timeToSec(times[n]); });

  // Midnight can be after 00:00 (e.g. 01:15), so its sec might be < Isha sec
  // We treat it as spanning midnight: it ends at Fajr
  const midSec  = secs['Midnight'];
  const fajrSec = secs['Fajr'];
  const ishaSec = secs['Isha'];

  const status = {};

  // Is it currently in the "Midnight window"?
  // Midnight window = from midSec until fajrSec (next day)
  // This can wrap around midnight: midSec > ishaSec means still same day after isha
  const inMidnightWindow = midSec > ishaSec
    ? (nowSec >= midSec || nowSec < fajrSec)   // e.g. 01:00 → wraps
    : (nowSec >= midSec && nowSec < fajrSec);   // both after midnight

  if (inMidnightWindow) {
    // Midnight is active, everything before it is passed
    order.forEach(n => {
      if (n === 'Midnight') status[n] = 'active';
      else if (n === 'Sunrise') status[n] = 'passed'; // Shuruq never active
      else status[n] = 'passed';
    });
    return status;
  }

  // Normal daytime logic
  // Find the last prayer (excl Shuruq/Midnight) whose time has passed
  const countable = ['Fajr', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'];
  let activeIdx = -1;
  for (let i = 0; i < countable.length; i++) {
    if (secs[countable[i]] <= nowSec) activeIdx = i;
  }

  order.forEach(n => {
    if (n === 'Sunrise') {
      // Shuruq: passed if nowSec >= its time, future otherwise — never "active"
      status[n] = secs[n] <= nowSec ? 'passed' : 'future';
      return;
    }
    if (n === 'Midnight') {
      status[n] = 'future';
      return;
    }
    const idx = countable.indexOf(n);
    if (idx < activeIdx) status[n] = 'passed';
    else if (idx === activeIdx) status[n] = 'active';
    else status[n] = 'future';
  });

  // Before Fajr: everything is future
  if (activeIdx === -1) {
    order.forEach(n => {
      if (status[n] !== 'future') status[n] = 'future';
    });
  }

  return status;
}

export default function HomeScreen() {
  const { theme: T } = useTheme();
  const { prayerTimes, tomorrowTimes, hijriDate, location, settings, isLoading, error, dispatch } = useApp();
  const { nextPrayer, secondsUntil } = useCountdown(prayerTimes);

  const [showModal,        setShowModal]        = useState(false);
  const [detectedLocation, setDetectedLocation] = useState(null);
  const [detecting,        setDetecting]        = useState(false);
  const [now,              setNow]              = useState(new Date());
  const [slideIndex,       setSlideIndex]       = useState(0);
  const touchStartX = useRef(null);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const loadPrayers = useCallback(async (loc, method) => {
    if (!loc) return;
    dispatch({ type: 'SET_LOADING', payload: true });
    dispatch({ type: 'SET_ERROR',   payload: null });
    try {
      const [todayRes, tomorrowTimings] = await Promise.all([
        fetchPrayerTimes(loc.latitude, loc.longitude, getTodayDateStr(), method),
        fetchTomorrowPrayerTimes(loc.latitude, loc.longitude, method),
      ]);
      const todayTimings = enrichWithMidnight(todayRes.timings, tomorrowTimings.Fajr);
      const tomTimings   = enrichWithMidnight(tomorrowTimings, null);
      dispatch({ type: 'SET_PRAYER_TIMES',   payload: todayTimings });
      dispatch({ type: 'SET_TOMORROW_TIMES', payload: tomTimings });
      dispatch({ type: 'SET_HIJRI',          payload: todayRes.hijri });
    } catch (e) {
      dispatch({ type: 'SET_ERROR', payload: e.message });
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, [dispatch]);

  useEffect(() => {
    if (location) loadPrayers(location, settings.calculationMethod);
  }, [location, settings.calculationMethod, loadPrayers]);

  useEffect(() => {
    if (!location) detectLocation();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const detectLocation = async () => {
    if (!navigator.geolocation) { setDetectedLocation(null); setShowModal(true); return; }
    setDetecting(true);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const { latitude, longitude } = pos.coords;
          const geo = await reverseGeocode(latitude, longitude);
          setDetectedLocation({ latitude, longitude, ...geo });
          setShowModal(true);
        } catch { setDetectedLocation(null); setShowModal(true); }
        finally { setDetecting(false); }
      },
      () => { setDetectedLocation(null); setShowModal(true); setDetecting(false); }
    );
  };

  const handleLocationConfirm = (loc) => {
    dispatch({ type: 'SET_LOCATION', payload: loc });
    setShowModal(false);
  };

  const nowSec = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const dateStr  = swedishDate(now);
  const hijriStr = formatHijri(hijriDate);

  const tomorrow = new Date(now); tomorrow.setDate(tomorrow.getDate() + 1);
  const tomDateStr = swedishDate(tomorrow);

  const onTouchStart = (e) => { touchStartX.current = e.touches[0].clientX; };
  const onTouchEnd   = (e) => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (dx < -50 && slideIndex === 0) setSlideIndex(1);
    if (dx > 50  && slideIndex === 1) setSlideIndex(0);
    touchStartX.current = null;
  };

  const isShowingTomorrow = slideIndex === 1;
  const activeTimes = isShowingTomorrow ? tomorrowTimes : prayerTimes;

  // Compute statuses for today only
  const prayerStatus = getPrayerStatus(prayerTimes, nowSec);

  const PrayerTable = ({ times, isTomorrow }) => {
    if (!times) return null;
    return (
      <>
        {PRAYER_NAMES.map((name) => {
          const st = isTomorrow ? 'future' : (prayerStatus[name] || 'future');
          const isPassed = st === 'passed';
          const isActive = st === 'active';

          return (
            <div key={name} style={{
              display:'flex', alignItems:'center', justifyContent:'space-between',
              padding:'13px 16px', borderRadius:14, marginBottom:7,
              border:'1px solid',
              background: isActive ? T.accent : T.card,
              borderColor: isActive ? T.accent : T.border,
              opacity: isPassed ? 0.32 : 1,
              transition:'opacity .4s, background .4s',
            }}>
              <div>
                <div style={{
                  fontSize:16, fontWeight:700,
                  color: isActive ? (T.isDark?'#0A0F2C':'#fff') : T.text,
                }}>
                  {PRAYER_SWEDISH[name]}
                </div>
                {isActive && (
                  <div style={{
                    fontSize:10, fontWeight:700, textTransform:'uppercase',
                    letterSpacing:1, marginTop:1,
                    color: T.isDark ? 'rgba(10,15,44,.5)' : 'rgba(255,255,255,.5)',
                  }}>
                    Pågår nu
                  </div>
                )}
              </div>
              <div style={{
                fontSize:18, fontWeight:700,
                fontFamily:"'DM Mono','Courier New',monospace",
                color: isActive ? (T.isDark?'#0A0F2C':'#fff') : T.textSecondary,
              }}>
                {fmt24(times[name])}
              </div>
            </div>
          );
        })}
      </>
    );
  };

  return (
    <div style={{ padding:'18px 16px 20px', background:T.bg, minHeight:'100%' }}
      onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>

      {showModal && (
        <LocationModal detected={detectedLocation} onConfirm={handleLocationConfirm}
          onClose={() => setShowModal(false)} theme={T} />
      )}

      {/* Header — no refresh button */}
      <div style={{ marginBottom:16, animation:'fadeUp .4s ease both' }}>
        <div style={{ fontSize:12, fontWeight:600, color:T.textMuted, textTransform:'capitalize', marginBottom:1 }}>
          {dateStr}
        </div>
        {hijriStr && (
          <div style={{ fontSize:12, color:T.accent, fontWeight:600, marginBottom:6 }}>
            {hijriStr}
          </div>
        )}
        <button onClick={detectLocation} style={{
          display:'flex', alignItems:'center', gap:5,
          background:'none', border:'none', padding:0, cursor:'pointer',
        }}>
          <span style={{ fontSize:22, fontWeight:800, color:T.text, letterSpacing:'-0.3px' }}>
            {location ? location.city : 'Välj plats'}
          </span>
          <span style={{ fontSize:14 }}>{detecting ? '⏳' : '📍'}</span>
        </button>
        {location?.country && (
          <div style={{ fontSize:12, color:T.textMuted, marginTop:1 }}>{location.country}</div>
        )}
      </div>

      {/* Error */}
      {error && (
        <div style={{
          padding:'11px 13px', borderRadius:11, border:'1px solid rgba(255,80,80,0.3)',
          background:'rgba(255,80,80,0.08)', marginBottom:12, fontSize:13, color:'#FF6B6B',
        }}>
          ⚠️ {error}
          <button onClick={() => loadPrayers(location, settings.calculationMethod)}
            style={{ marginLeft:8, color:T.accent, background:'none', border:'none', fontWeight:700, cursor:'pointer' }}>
            Försök igen
          </button>
        </div>
      )}

      {/* No location */}
      {!location && !isLoading && (
        <div style={{ textAlign:'center', paddingTop:40 }}>
          <div style={{ fontSize:52, marginBottom:12 }}>🕌</div>
          <div style={{ fontSize:20, fontWeight:700, color:T.text, marginBottom:8 }}>Ange din plats</div>
          <div style={{ fontSize:14, color:T.textMuted, lineHeight:1.6, maxWidth:260, margin:'0 auto 22px' }}>
            Vi behöver din plats för att visa korrekta bönetider.
          </div>
          <button onClick={detectLocation} style={{
            padding:'13px 28px', borderRadius:14, background:T.accent,
            color:T.isDark?'#0A0F2C':'#fff', fontSize:15, fontWeight:700, border:'none', cursor:'pointer',
          }}>
            Hitta min plats
          </button>
        </div>
      )}

      {/* Loading */}
      {isLoading && !prayerTimes && (
        <div>
          {[1,2,3,4,5,6,7].map(i => (
            <div key={i} style={{ height:50, borderRadius:14, marginBottom:7, background:T.card, border:`1px solid ${T.border}`, overflow:'hidden' }}>
              <div style={{ height:'100%', width:'100%', background:`linear-gradient(90deg, transparent 25%, ${T.border} 50%, transparent 75%)`, backgroundSize:'200% 100%', animation:'shimmer 1.5s infinite' }}/>
            </div>
          ))}
        </div>
      )}

      {/* Countdown */}
      {prayerTimes && nextPrayer && (
        <div style={{
          background:T.bgSecondary, border:`1px solid ${T.border}`, borderRadius:18,
          padding:'16px 14px 14px', textAlign:'center', marginBottom:14,
          position:'relative', overflow:'hidden',
        }}>
          <div style={{ position:'absolute', bottom:0, left:0, right:0, height:3, background:T.accent, opacity:.6 }}/>
          <div style={{ fontSize:10, fontWeight:700, letterSpacing:'1.5px', textTransform:'uppercase', color:T.textMuted, marginBottom:5 }}>
            Tid kvar till {PRAYER_SWEDISH[nextPrayer]}
          </div>
          <div style={{ fontSize:44, fontWeight:800, color:T.text, letterSpacing:'3px', lineHeight:1, fontFamily:"'DM Mono','Courier New',monospace" }}>
            {fmtCountdown(secondsUntil)}
          </div>
          <div style={{ fontSize:12, color:T.textMuted, marginTop:7 }}>
            {PRAYER_SWEDISH[nextPrayer]} kl. {fmt24(prayerTimes[nextPrayer])}
          </div>
        </div>
      )}

      {/* Slide header + dots */}
      {prayerTimes && (
        <>
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:8 }}>
            <div style={{ fontSize:11, fontWeight:700, letterSpacing:'1.4px', textTransform:'uppercase', color:T.textMuted }}>
              {isShowingTomorrow ? `Imorgon · ${tomDateStr}` : 'Dagens böner'}
            </div>
            <div style={{ display:'flex', gap:5, alignItems:'center' }}>
              {[0,1].map(i => (
                <div key={i} onClick={() => setSlideIndex(i)} style={{
                  width: slideIndex===i ? 16 : 7, height:7, borderRadius:4,
                  background: slideIndex===i ? T.accent : T.border,
                  transition:'all .3s', cursor:'pointer',
                }}/>
              ))}
            </div>
          </div>
          {slideIndex === 0 && (
            <div style={{ fontSize:11, color:T.textMuted, textAlign:'right', marginBottom:6, marginTop:-4 }}>
              ← Swipe för imorgon
            </div>
          )}

          <PrayerTable times={activeTimes} isTomorrow={isShowingTomorrow} />
        </>
      )}
    </div>
  );
}
